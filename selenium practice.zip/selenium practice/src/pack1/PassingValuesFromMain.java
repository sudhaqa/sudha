package pack1;



public class PassingValuesFromMain {
public static void main(String[] args) {
	
	
}
}
