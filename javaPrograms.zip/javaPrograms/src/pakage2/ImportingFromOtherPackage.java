package pakage2;

import pakage1.VoidMethod; // importing classes from other packages

public class ImportingFromOtherPackage {
VoidMethod obj = new VoidMethod();
public static void main(String[] args) {
	
}

}
