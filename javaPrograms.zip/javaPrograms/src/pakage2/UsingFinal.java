package pakage2;

public class UsingFinal {
	final static double pi = 3.141;
	
	public static void main(String[] args) {
		int radius = 5;
		System.out.println("Area of circle: "+(pi*radius*radius));
	}
	

}
