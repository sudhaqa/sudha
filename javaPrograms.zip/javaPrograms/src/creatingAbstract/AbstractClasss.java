package creatingAbstract;

public abstract class AbstractClasss { //if class contains at least one abstract method then the class must be declared as abstract
	
	void car(){
		System.out.println("Name of the car: Volvo");
	}
	
	public abstract void CarProperties(); // abstract method
 
	
}