package creatingAbstract;

public class extendingAbstract extends AbstractClasss{

	@Override
	public void CarProperties() {
		
		System.out.println(" implementing the un implemented ");
		
	}
	
	

}