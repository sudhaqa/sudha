package pakage1;

public class StaticProperty {

	static String Name="this is a static property";
	public static void main(String[] args) {
		System.out.println(Name); // no need to create an object as the property is static 
	}
	
	
}