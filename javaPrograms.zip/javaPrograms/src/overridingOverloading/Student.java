package overridingOverloading;

public class Student {
public void studentAddress()
{
	System.out.println("Inside parent class");
}
}
