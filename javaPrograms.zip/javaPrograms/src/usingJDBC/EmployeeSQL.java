package usingJDBC;

public class EmployeeSQL {

}
