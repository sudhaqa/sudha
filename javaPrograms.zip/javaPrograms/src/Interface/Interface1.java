package Interface;

public interface Interface1 {
public void car(); // all methods in interface are abstract

public void carColor();
	
}
